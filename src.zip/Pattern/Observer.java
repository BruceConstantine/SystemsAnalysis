package Pattern;

//import java.util.ArrayList;

public /* One Observer has Many Subject: interface & Attribute: ArrayList< Subject > SubjectList = new ArrayList< Subject >(); */
interface Observer {
	//Subject subject; // One Observer has one Subject
	public abstract void update();
}
