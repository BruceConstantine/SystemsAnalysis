package Pattern;

import java.util.ArrayList;

public interface Subject {

	ArrayList< Observer >observersList = new ArrayList< Observer >();
	
//	public abstract void getVehiclePos();				 
//	public abstract void setVehiclePos();
	public abstract void notifyObs();
	public abstract void registerObs(Observer observer);
	
	//	void deleteObs();
}



/*
 * 
 * 
public  abstract class Subject {
	
	Observer observer; // One Subject has One Observer
	
	public abstract void getVehiclePos();				//getState()
	public abstract void setVehiclePos();
	public abstract void notifyObs();
	public abstract void registerObs();
	
	//	void deleteObs();
}
 
 */