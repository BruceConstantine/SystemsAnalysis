package Vehicle;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Truck extends Vehicle{
	public Truck() {
		 try {
			vehicle_Img = ImageIO.read(new File("resource/truck.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
