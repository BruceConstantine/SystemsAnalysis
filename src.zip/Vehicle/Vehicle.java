package Vehicle;

import java.awt.Image;

public abstract class Vehicle {
	
	private double velocity;
	private double acceleration;
	/// TODO: NOTICE!
	private double posX;
	private double posY;
	
	protected Image vehicle_Img;
	
	public Image getVehicle_Img() {
		return this.vehicle_Img;
	}
	//No setter for Vehicle_Img.
	public double getPosX() {
		return posX;
	}
	public void setPosX(double posX) {
		this.posX = posX;
	}
	public double getPosY() {
		return posY;
	}
	public void setPosY(double posY) {
		this.posY = posY;
	}
	
	public double getVelocity() {
		return velocity;
	}
	public void setVelocity(double velocity) {
		this.velocity = velocity;
	}
	public double getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(double acceleration) {
		this.acceleration = acceleration;
	}
	
}
