//Robert O'Driscoll ---- 14150808
//CS4125 - Systems Analysis & Design
//Traffic Simulator
//ObserverMock.java
//Used for testing purposes
package test;
public interface ObserverMock{
	// subject attributes.....
	// .....
	
	//update()
    public abstract void update();
}
