//Robert O'Driscoll ---- 14150808
//CS4125 - Systems Analysis & Design
//Traffic Simulator
//GraphicsDriver
//Used for testing purposes
package test;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferStrategy;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import Map.Map;

import javax.imageio.ImageIO;

import Pattern.Observer;
import Vehicle.Vehicle;
import java.awt.Canvas;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

import Map.Map;
import Vehicle.Vehicle;
 
public class GraphicsDriver {

    public static void main(String [] args) throws Exception {

       new fram();
       // TWindow window = new TWindow();
        

    }
}
class fram extends JFrame{
	public fram() throws IOException {
		 super("Traffic Simulator");
	        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        this.setSize(800, 600);
	        this.setResizable(false);
	        new cav();
	       // this.add( );
	        setVisible(true);
	}
}

class cav extends Canvas{
	Image background_image ;

	public cav() throws IOException {
		File file = new File("resource/backgroundGrass.jpg"); 
		background_image = ImageIO.read(file);
	}
	public void update(Graphics g) {
        paint(g);
    }
	public void paint(Graphics g) {
	    BufferStrategy buffer;
		 
        buffer = getBufferStrategy();
        if(buffer == null) {
            createBufferStrategy(2);
            return ;
        }
         
            g =  buffer.getDrawGraphics();
            g.drawImage(background_image, 0, 0, null);
            
            buffer.show();
    		/***what's this ?*/
            g.dispose(); 
    }
}