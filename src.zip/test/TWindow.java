//Robert O'Driscoll ---- 14150808
//CS4125 - Systems Analysis & Design
//Traffic Simulator
//TWindow.java
package test;
import javax.swing.JFrame;
import java.io.IOException;
import java.awt.Graphics;

// concrete observer class
public class TWindow extends JFrame /*implements ObserverMock */{

	// class TWindow is an GUI & Observer
	
	//observer should has a subject...
   // private SubjectMock subject;

	//Window has a Canvas
    private TCanvas canvas;
	
	//Constructor for window:	add 'this' pointer -- the observer into the subject 
	//							&& initial basic component
    TWindow(/*SubjectMock subject*/) throws IOException {

        super("Traffic Simulator");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 600);
        this.setResizable(false);

        canvas = new TCanvas();
        this.add(canvas);
        setVisible(true);

     //   this.subject = subject;
     //   this.subject.attach(this);
    }

//	//override the update() from Observer Interface.
//	@Override
//    public void update() {
//        canvas.setCarX(subject.getCarPosition());
//        Graphics g = canvas.getGraphics();
//        canvas.update(g);
//
//    }
}
