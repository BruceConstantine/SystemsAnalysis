//Robert O'Driscoll ---- 14150808
//CS4125 - Systems Analysis & Design
//Traffic Simulator
//TCanvas.java
package test;
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferStrategy;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import Map.Map;

import javax.imageio.ImageIO;

import Pattern.Observer;
import Vehicle.Vehicle;


public class TCanvas extends Canvas implements Observer {

//actually, the canvas should contains Map rather just road & cars


    private Image background_image;
    private Image road_image;
//    private Image car_image;

	/***what's this ?*/
    private BufferStrategy buffer;
	ArrayList<Vehicle> vehicles;
//############Refactor#########
//    private int car_x; // will be changed
 //   private int car_y; // will be changed
//#END#######Refactor##########
    Map map ;


	// Constructor init : car position && car looks in this canvas
    TCanvas() throws IOException{
        map = new Map();
        vehicles = map.getVehicleAll();
        background_image = ImageIO.read(new File("resource/backgroundGrass.jpg"));
        road_image = map.getLane().getLaneImage();
//        car_image= ImageIO.read(new File("resource/car-top-view.png"));
//        car_x = 0;
//        car_y = 160;
    }

	// see method update() following
    public void paint(Graphics g) {
        buffer = getBufferStrategy();
        if(buffer == null) {
            createBufferStrategy(2);
            return ;
        }
        for(Vehicle v: vehicles){
            g =  buffer.getDrawGraphics();
            g.drawImage(background_image, 0, 0, null);
            g.drawImage(road_image, 0, 165, null);
            g.drawImage(v.getVehicle_Img(), (int) v.getPosX(), (int) v.getPosY(), null);
            buffer.show();
    		/***what's this ?*/
            g.dispose();
        }     
    }

	// update canvas rather than override observer
    public void update(Graphics g) {
        paint(g);
    }

	// set method for set car position: This method should be allocated into others class 
//    public void setCarX(int x) {
//        car_x = x;
//    }
//
//    public void setCarY(int y) {
//        car_y = y;
//    }

	@Override
	public void update() {
		Vehicle v = null;
		 
        //this.setCarX();
        this.update( this.getGraphics() );

		
	}

}
