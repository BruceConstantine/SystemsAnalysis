package TSF_Util;
import GlobalContract.* ;
import Vehicle.Vehicle;


public class Formula {

	// This just used to describe  uniformly accelerated rectilinear motion 
	public static final double getDeltaDisplacement(Vehicle vehicle) {
		double a = vehicle.getAcceleration();
		double v = vehicle.getVelocity();
		double t = TimeControl.TIME_UNIT * ScaleControl.TIME_ScaleRatio;
		double dispalcement = a * t * t / 2 + v * t;
		return dispalcement;
	}
	
	public static final double getDeltaVolecity(Vehicle vehicle) {
		return vehicle.getAcceleration() * (TimeControl.TIME_UNIT * ScaleControl.TIME_ScaleRatio);
	}
}
