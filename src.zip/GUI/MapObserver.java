package GUI;

import Pattern.Observer;

public class MapObserver   {
	
}
