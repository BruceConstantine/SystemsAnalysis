package GUI;

import Pattern.Observer;

public class MainWindow implements Observer{
	MapObserver mapObserver;
	
	@Override
	public void update(){
		
	}
}
