package Map;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.Timer;

import Pattern.Observer;
import Pattern.Subject;
import Road.Lane;
import Road.StraightLane;
import Vehicle.Truck;
import Vehicle.Vehicle;

public class Map implements Subject{

	///TODO:Refactor Lane as Road.
	Lane lane;
	ArrayList<Vehicle> vehicle_list = new ArrayList<Vehicle>(1); //refactor 1 as random later.
	Timer timer;
	
	public Map(){
		lane = new StraightLane();
		
		generateVehicle();
		
		timer = new Timer(GlobalContract.TimeControl.TIME_UNIT, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(Iterator<Vehicle> iterator = vehicle_list.iterator();
					iterator.hasNext(); 
						){
					Vehicle eachVehicle = iterator.next();
					
					//change car's position
					double deltaX = TSF_Util.Formula.getDeltaDisplacement(eachVehicle);
					eachVehicle.setPosX( eachVehicle.getPosX() + deltaX );
				
					//change car's volecity
					double deltaVolecity = TSF_Util.Formula.getDeltaVolecity(eachVehicle);
					eachVehicle.setVelocity(eachVehicle.getVelocity() + deltaVolecity);
					/// !!NOTICE: The Car's position should be updated firstly.
				}
				notifyObs();
			}
		});
		
	}
	
	public ArrayList<Vehicle> getVehicleAll(){
		return this.vehicle_list;
	}
	
	/// TODO: Refactor Here After iteration 1.
	/// NOTICE: the method modefier is public?
	public void generateVehicle(){
		//generate vehicle in here!
		Vehicle truck = new Truck();
		vehicle_list.add(truck);
	}
	
	public Lane getLane() {
		return lane;
	}

	public void setLane(Lane lane) {
		this.lane = lane;
	}

	@Override
	public void notifyObs() {
		for(Observer o: observersList){
			o.update();
		}
	}

	@Override
	public void registerObs(Observer observer) {
		observersList.add(observer);
	}

}
