package GlobalContract;

public interface LaneStipulation {
	double width = 40; // meters.
}
