package GlobalContract;


public class TimeControl {
	public static final int TIME_UNIT = 1000; // milisecond.
}
