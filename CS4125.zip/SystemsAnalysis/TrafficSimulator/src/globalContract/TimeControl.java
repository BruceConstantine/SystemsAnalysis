package globalContract;


public class TimeControl {
	public static final int TIME_UNIT = 5; // milisecond.
}
