package road;


public class Road {
	Lane lane [];
	/***
	 * In this class Road:
	 * 		It show be refactor:
	 * 			rename as anvenue et al..
	 * 		lane-> just a signle lane : straight lane, ring lane, overpass etc.
	 * 		anvenue -> lots of lanes in the class, generally 3 or 2 lane for each road & 
	 * 
	 * Question: How to dispaly Vehicle and Road on the map?
	 * */
}
