package driver;


public interface Behavior
{
    void drive();
}
