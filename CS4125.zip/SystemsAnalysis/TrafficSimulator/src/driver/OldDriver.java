package driver;

// actual functionaly will have to be put in the subclasses..
public class OldDriver implements Behavior {
    public void drive()
    {
        System.out.println("I can't see");
    }
}
