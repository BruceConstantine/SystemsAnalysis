package driver;


public class YoungDriver implements Behavior {

    public void drive() {
        System.out.println("I'm a total nut bar");
    }
}
