package vehicle;


public class Truck extends Vehicle{

	public Truck(double max_speed, double acceleration)
	{
		super(max_speed, acceleration);
	}
}
