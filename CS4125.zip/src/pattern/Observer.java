//Robert O'Driscoll ---- 14150808
//CS4125 - Systems Analysis & Design
//Traffic Simulator
//Observer.java
//Used for testing purposes
package pattern;
public interface Observer{
    void update();
}
