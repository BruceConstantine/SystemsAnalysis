package globalContract;


public class TimeControl {
	/*fps*/
	public static final int TIME_UNIT = 5; // milisecond.
	//TIME_UNIT CANNOT BIGGR 5 : COZ THE OVERTAKKING WILL OCURR BIG BUG.
}
