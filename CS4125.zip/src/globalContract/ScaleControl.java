package globalContract;

public final class ScaleControl {
	public final static int MAP_ScaleRatio = 10;  //fix scale ratio: 10px = 1m.
	public final static double TIME_ScaleRatio = 1 ; // 1s in real life = 10 s in this project.
}
