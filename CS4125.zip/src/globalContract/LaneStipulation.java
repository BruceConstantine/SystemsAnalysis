package globalContract;

public interface LaneStipulation {
	double width = 40; // meters.
}
