package driver;


public class YoungDriver implements Behavior {
	
	public int changeLaneDuration = 1000;
	
    public void drive() {
        System.out.println("I'm a total nut bar");
    }
}
