package driver;


public interface Behavior
{
	public abstract void drive();
    //public abstract void changeLane() ;
}
